function hardcore:modes/normal
