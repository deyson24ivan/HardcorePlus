function hardcore:modes/show
