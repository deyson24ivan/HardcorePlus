function hardcore:modes/apocalipsis
