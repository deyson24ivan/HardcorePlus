function hardcore:stats/show
