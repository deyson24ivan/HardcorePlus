function hardcore:stats/points
