function hardcore:bosses/clear
