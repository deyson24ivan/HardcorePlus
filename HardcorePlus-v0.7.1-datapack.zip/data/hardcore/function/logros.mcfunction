function hardcore:achievements/show
