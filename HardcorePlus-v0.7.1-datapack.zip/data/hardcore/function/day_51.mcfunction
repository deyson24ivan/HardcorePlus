function hardcore:modes/pesadilla
