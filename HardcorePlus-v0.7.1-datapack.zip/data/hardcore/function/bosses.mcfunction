function hardcore:bosses/help
